/* Get Elements */
const size = document.getElementById('size');
const output = document.getElementById('output');
const inc = document.getElementById('inc');
const dec = document.getElementById('dec');
const reset = document.getElementById('reset')

/* Do Increment */

inc.addEventListener('click',()=>{
  let currentSize = parseInt(size.innerHTML);
  currentSize++;
  size.innerHTML = currentSize;
  output.style.fontSize = currentSize + 'px';
});
/* Do Decrement */
dec.addEventListener('click', ()=>{
  let currentSize =parseInt(size.innerHTML);
  currentSize--;
  size.innerHTML = currentSize;
  output.style.fontSize = currentSize + 'px';
})
/* Reset */
reset.addEventListener('click', ()=>{
  size.innerHTML = 16;
  output.style.fontSize = '16px'
})
